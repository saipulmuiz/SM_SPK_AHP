# Metode-AHP
Sistem Pendukung Keputusan Menggunakan Metode AHP (Analitycal Hierarchy Process).
